//
//  sdp_process.h
//  libsofia-sip
//
//  Created by Bill Tocute on 2011/11/3.
//  Copyright 2011年 Quanta. All rights reserved.
//
#ifndef _SDP_PROCESS_H
#define _SDP_PROCESS_H

#include "sip_call.h"
#include "sip_call_engine.h"
#define nua_magic_t EngineData

using namespace call;
namespace sipcall
{
    void SDPTomdpList(sdp_rtpmap_t *rtpmap,std::list<struct call::MDP*> *list)
    {
        //reset old mdp
        empty_mdp_list(list);
        
        //parse new mdp
        while (rtpmap != NULL)
        {
            MDP *mdp_data = new MDP();
            strcpy(mdp_data->mime_type,rtpmap->rm_encoding);
            mdp_data->payload_id = rtpmap->rm_pt;
            mdp_data->clock_rate = rtpmap->rm_rate;
            mdp_data->bitrate    = 0;
            if(rtpmap->rm_fmtp != NULL)
            {
                char *pch =  strtok((char*)rtpmap->rm_fmtp,"=");
                while (pch != NULL)
                {
                    if (strcasecmp(pch, "bitrate")==0)
                    {
                        pch = strtok (NULL, "=");
                        mdp_data->bitrate = atoi(pch);
                        break;
                    }
                    pch = strtok (NULL, "=");
                } 
            }
            list->push_back(mdp_data);
            rtpmap = rtpmap->rm_next;
        }
    }
    
    const MDP* mappingMDP(std::list<struct call::MDP*> localMDP,std::list<struct call::MDP*>remoteMDP)
    {
        for (std::list<struct call::MDP*>::iterator local=localMDP.begin(); local!=localMDP.end(); local++)
        {
            for (std::list<struct call::MDP*>::iterator remote=remoteMDP.begin(); remote!=remoteMDP.end(); remote++)
            {        
                if(strcasecmp((*local)->mime_type,(*remote)->mime_type) == 0 && 
                   (*local)->clock_rate == (*remote)->clock_rate && 
                   (*local)->bitrate    == (*remote)->bitrate)
                {
                    return *remote;
                }
                
            }
        }
        return NULL;
    }
    
    bool mappingSDP(nua_magic_t  *magic, SipCall *sipCall)
    {
        bool is_audio_match = false;
        bool is_video_match = false;
        //reset mdp
        initMDP(&sipCall->mCallData.audio_mdp);
        initMDP(&sipCall->mCallData.video_mdp);
        
        if(sipCall->remoteAudioMDP.size() > 0)
        {
            const MDP* mdp = mappingMDP(magic->local_audio_mdps , sipCall->remoteAudioMDP);
            if(mdp != NULL)
            {
                copyMDP(&sipCall->mCallData.audio_mdp, mdp);
                sipCall->mCallData.is_video_call = false;
                is_audio_match = true;
            }
        }
        if (sipCall->remoteAudioMDP.size()==0 || is_audio_match == false )
        {
            sipCall->mCallData.remote_audio_port = 0;
        }
        
        if(sipCall->remoteVideoMDP.size() > 0)
        {
            const MDP* mdp = mappingMDP(magic->local_video_mdps , sipCall->remoteVideoMDP);
            if(mdp != NULL)
            {
                copyMDP(&sipCall->mCallData.video_mdp, mdp);
                sipCall->mCallData.is_video_call = true;
                is_video_match = true;
            }
        }
        if (sipCall->remoteVideoMDP.size()==0 || is_video_match == false)
        {
            sipCall->mCallData.remote_video_port = 0;
        }
        return is_audio_match || is_video_match;
    }
    
    void parseSDP(const char *sdp_string , SipCall  *sipCall)
    {
        su_home_t g_su_home;
        su_home_init(&g_su_home);
        sdp_parser_t *local_parser = sdp_parse(&g_su_home, sdp_string, strlen(sdp_string), sdp_f_insane);
        sdp_session_t *l_sdp = sdp_session(local_parser);
        
        printf("receiver SDP \n%s",sdp_string);

        if (l_sdp->sdp_media != NULL)
        {
            //get product_type
            //sdp_attribute_t  *attributes = l_sdp->sdp_media->m_attributes;
            while (l_sdp->sdp_media->m_attributes != NULL) 
            {
                if(strcasecmp(l_sdp->sdp_media->m_attributes->a_name, "tool") == 0)
                {
                    if(strstr(l_sdp->sdp_media->m_attributes->a_value,"Quanta") != NULL)
                    {
                        if(strstr(l_sdp->sdp_media->m_attributes->a_value,"ET1") != NULL)
                            sipCall->mCallData.product_type = PRODUCT_TYPE_PX;
                        else if(strstr(l_sdp->sdp_media->m_attributes->a_value,"QT1.5A") != NULL)
                            sipCall->mCallData.product_type = PRODUCT_TYPE_QTA;
                        else if(strstr(l_sdp->sdp_media->m_attributes->a_value,"QT1.5W") != NULL)
                            sipCall->mCallData.product_type = PRODUCT_TYPE_QTW;
                        else if(strstr(l_sdp->sdp_media->m_attributes->a_value,"QT1.5I") != NULL)
                            sipCall->mCallData.product_type = PRODUCT_TYPE_QTI;
                    }
                }
                l_sdp->sdp_media->m_attributes = l_sdp->sdp_media->m_attributes->a_next;
            }
            //l_sdp->sdp_media->m_attributes = attributes;
        }
        
        empty_mdp_list(&sipCall->remoteAudioMDP);
        empty_mdp_list(&sipCall->remoteVideoMDP);
        sipCall->mCallData.remote_video_port = 0;
        sipCall->mCallData.remote_audio_port = 0;
        sipCall->mCallData.is_video_call = false;
        //bool is_audio_hold = false;
        //bool is_video_hold = false;
        while (l_sdp->sdp_media != NULL)
        {
            if (strcasecmp(l_sdp->sdp_media->m_type_name,"audio") == 0) 
            {
                memset(sipCall->mCallData.remote_audio_ip,0,sizeof(sipCall->mCallData.remote_audio_ip));
                if(l_sdp->sdp_connection != NULL && l_sdp->sdp_connection->c_address != NULL)
                    strcpy(sipCall->mCallData.remote_audio_ip, l_sdp->sdp_connection->c_address);
                if(l_sdp->sdp_media->m_connections != NULL && l_sdp->sdp_media->m_connections->c_address != NULL)
                    strcpy(sipCall->mCallData.remote_audio_ip, l_sdp->sdp_media->m_connections->c_address);
                sipCall->mCallData.remote_audio_port = (unsigned int)l_sdp->sdp_media->m_port;
                if (sipCall->mCallData.remote_audio_port != 0) 
                {
                    SDPTomdpList(l_sdp->sdp_media->m_rtpmaps,&sipCall->remoteAudioMDP);
                    sipCall->mCallData.is_video_call = false;
                }
                /*sofia sip can not parse
                while (l_sdp->sdp_media->m_attributes != NULL) 
                {
                    if(strcasecmp(l_sdp->sdp_media->m_attributes->a_name, "inactive") == 0)
                    {
                        is_audio_hold = true;
                    }
                    l_sdp->sdp_media->m_attributes = l_sdp->sdp_media->m_attributes->a_next;
                }*/
            }
            else if (strcasecmp(l_sdp->sdp_media->m_type_name,"video") == 0) 
            {
                memset(sipCall->mCallData.remote_video_ip,0,sizeof(sipCall->mCallData.remote_video_ip));
                if(l_sdp->sdp_connection != NULL && l_sdp->sdp_connection->c_address != NULL)
                    strcpy(sipCall->mCallData.remote_video_ip, l_sdp->sdp_connection->c_address);
                if(l_sdp->sdp_media->m_connections != NULL && l_sdp->sdp_media->m_connections->c_address != NULL)
                    strcpy(sipCall->mCallData.remote_video_ip, l_sdp->sdp_media->m_connections->c_address);
                sipCall->mCallData.remote_video_port = (unsigned int)l_sdp->sdp_media->m_port;
                if (sipCall->mCallData.remote_video_port != 0) 
                {
                    SDPTomdpList(l_sdp->sdp_media->m_rtpmaps,&sipCall->remoteVideoMDP);
                    sipCall->mCallData.is_video_call = true;
                }
                /*sofia sip can not parse
                while (l_sdp->sdp_media->m_attributes != NULL) 
                {
                    if(strcasecmp(l_sdp->sdp_media->m_attributes->a_name, "inactive") == 0)
                    {
                        is_video_hold = true;
                    }
                    l_sdp->sdp_media->m_attributes = l_sdp->sdp_media->m_attributes->a_next;
                }*/
            }
            l_sdp->sdp_media = l_sdp->sdp_media->m_next;
        }
        
        bool is_hold = false;
        while (l_sdp->sdp_attributes != NULL) 
        {
            if(strcasecmp(l_sdp->sdp_attributes->a_name, "inactive") == 0)
            {
                is_hold = true;
            }
            l_sdp->sdp_attributes = l_sdp->sdp_attributes->a_next;
        }
        
        if (strcmp(sipCall->mCallData.remote_audio_ip, "0.0.0.0")==0 ||
            is_hold       == true ||
            strstr(sdp_string, "inactive") != NULL)
        {
            sipCall->mCallData.call_state = CALL_STATE_HOLD;
        }
        else if(sipCall->mCallData.call_state == CALL_STATE_HOLD)
        {
            sipCall->mCallData.call_state = CALL_STATE_UNHOLD;
        }
        
        //sdp_printer_t *printer = sdp_print(&g_su_home, l_sdp, NULL, 0, sdp_f_config | sdp_f_insane);
        //const char *l_sdp_str = sdp_message(printer);
        //sdp_printer_free(printer);
        sdp_parser_free(local_parser);
        su_home_deinit(&g_su_home);
    }
    
    void makeSDP(EngineData engineData,const CallData  callData,char* sdp_string)
    {
        memset(sdp_string, 0, sizeof(sdp_string));
    
        //sprintf(sdp_string, "c=IN IP4 %s\r\n",callData.local_audio_ip);
    
        //a=inactive
        //if(callData.call_state == CALL_STATE_HOLD)
        //    sprintf(sdp_string, "%sa=inactive\r\n",sdp_string);
    
        //make audio sdp
        if(engineData.local_audio_mdps.size() > 0 && callData.local_audio_port != 0) //port = 0 disable
        {
            //m=audio 4444 RTP/AVP 0 8\r\n a=rtpmap:0 PCMU/8000\r\n a=rtpmap:8 PCMA/8000\r\n 
            sprintf(sdp_string, "m=audio %d RTP/AVP",callData.local_audio_port);
            if(callData.is_reinvite == true && strlen(callData.audio_mdp.mime_type) != 0)
            {
                sprintf(sdp_string, "%s %d\r\n",sdp_string,callData.audio_mdp.payload_id);
                //sprintf(sdp_string, "%sc=IN IP4 %s\r\n",sdp_string,callData.local_audio_ip);
                //a=rtpmap:0 PCMU/8000\r\n
                sprintf(sdp_string, "%sa=rtpmap:%d %s/%d\r\n",sdp_string,callData.audio_mdp.payload_id,callData.audio_mdp.mime_type,callData.audio_mdp.clock_rate);
            
                if(callData.audio_mdp.bitrate != 0)
                    sprintf(sdp_string, "%sa=fmtp:%d bitrate=%d\r\n",sdp_string,callData.audio_mdp.payload_id,callData.audio_mdp.bitrate);
            }
            else  //first make call
            {
                for (std::list<struct call::MDP*>::iterator it=engineData.local_audio_mdps.begin(); it!=engineData.local_audio_mdps.end() ; it++)
                {
                    sprintf(sdp_string, "%s %d",sdp_string,(*it)->payload_id);
                }
                sprintf(sdp_string, "%s\r\n",sdp_string);
                //sprintf(sdp_string, "%sc=IN IP4 %s\r\n",sdp_string,callData.local_audio_ip);
                //a=rtpmap:0 PCMU/8000\r\n
                for (std::list<struct call::MDP*>::iterator it=engineData.local_audio_mdps.begin(); it!=engineData.local_audio_mdps.end(); it++)
                {
                    sprintf(sdp_string, "%sa=rtpmap:%d %s/%d\r\n",sdp_string,(*it)->payload_id,(*it)->mime_type,(*it)->clock_rate);
                
                    if((*it)->bitrate != 0)
                        sprintf(sdp_string, "%sa=fmtp:%d bitrate=%d\r\n",sdp_string,(*it)->payload_id,(*it)->bitrate);
                }
            }
            //a=ptime:20
            sprintf(sdp_string, "%sa=ptime:20\r\n",sdp_string);
        
            //a=tool:Quanta QT1.5A_0.0.1
            switch (engineData.product_type) 
            {
                case call::PRODUCT_TYPE_NA:
                    break;
                case call::PRODUCT_TYPE_PX:
                    sprintf(sdp_string, "%sa=tool:Quanta ET1_0.0.1\r\n",sdp_string);
                    break;
                case call::PRODUCT_TYPE_QTA:
                    sprintf(sdp_string, "%sa=tool:Quanta QT1.5A_0.0.1\r\n",sdp_string);
                    break;
                case call::PRODUCT_TYPE_QTI:
                    sprintf(sdp_string, "%sa=tool:Quanta QT1.5I_0.0.1\r\n",sdp_string);
                    break;
                case call::PRODUCT_TYPE_QTW:
                    sprintf(sdp_string, "%sa=tool:Quanta QT1.5W_0.0.1\r\n",sdp_string);
                    break;
                default:
                    break;
            } 
        }
        //make video sdp
        if(engineData.local_video_mdps.size() > 0 && callData.local_video_port != 0)
        {
            //m=video 6666 RTP/AVP 109\r\n a=rtpmap:109 H264/90000
            sprintf(sdp_string, "%sm=video %d RTP/AVP",sdp_string,callData.local_video_port);
            if(callData.is_reinvite == true && strlen(callData.video_mdp.mime_type) != 0)
            {
                sprintf(sdp_string, "%s %d\r\n",sdp_string,callData.video_mdp.payload_id);
                //sprintf(sdp_string, "%sc=IN IP4 %s\r\n",sdp_string,callData.local_video_ip);
                //a=rtpmap:0 PCMU/8000\r\n
                sprintf(sdp_string, "%sa=rtpmap:%d %s/%d\r\n",sdp_string,callData.video_mdp.payload_id, callData.video_mdp.mime_type, callData.video_mdp.clock_rate);
            
                if(strcasecmp("H264",callData.video_mdp.mime_type)==0)
                {
                    sprintf(sdp_string, "%sa=fmtp:%d profile-level-id=42E01E;packetization-mode=1\r\n",sdp_string,callData.video_mdp.payload_id);
                }
            }
            else //first make call
            {
                for (std::list<struct call::MDP*>::iterator it=engineData.local_video_mdps.begin(); it!=engineData.local_video_mdps.end() ; it++)
                {
                    sprintf(sdp_string, "%s %d",sdp_string,(*it)->payload_id);
                }
                sprintf(sdp_string, "%s\r\n",sdp_string);
                //sprintf(sdp_string, "%sc=IN IP4 %s\r\n",sdp_string,callData.local_video_ip);
            
                for (std::list<struct call::MDP*>::iterator it=engineData.local_video_mdps.begin(); it!=engineData.local_video_mdps.end(); it++)
                {
                    sprintf(sdp_string, "%sa=rtpmap:%d %s/%d\r\n",sdp_string,(*it)->payload_id,(*it)->mime_type,(*it)->clock_rate);
                
                    //a=fmtp:109 profile-level-id=42E01E;packetization-mode=1
                    if(strcasecmp("H264", (*it)->mime_type)==0)
                    {
                        sprintf(sdp_string, "%sa=fmtp:%d profile-level-id=42E01E;packetization-mode=1\r\n",sdp_string,(*it)->payload_id);
                    }
                }
            }
            //a=ptime:20
            sprintf(sdp_string, "%sa=ptime:20\r\n",sdp_string);
        }
    
    //const char *CAPS = "v=0\nm=audio 0 RTP/AVP 0\na=rtpmap:0 PCMU/8000";
    /*sdp_parser_t *local_parser = sdp_parse(NULL, sdp_string, strlen(sdp_string), sdp_f_insane);
     sdp_session_t *l_sdp       = sdp_session(local_parser);
     if(l_sdp && l_sdp->sdp_media)
     {
     l_sdp->sdp_origin->o_version = 16384;
     l_sdp->sdp_origin->o_id      = 16384;
     }
     
     sdp_printer_t *printer = sdp_print(NULL, l_sdp, NULL, 0, sdp_f_config | sdp_f_insane);
     ;
     sdp_string = (char*)sdp_message(printer);
     sdp_printer_free(printer);
     sdp_parser_free(local_parser);*/
    }

    bool answerSDP(EngineData engineData,SipCall *sipCall,char* sdp_string)
    {
        memset(sdp_string, 0, sizeof(sdp_string));
        bool is_match = false;  
        
        //reset mdp
        initMDP(&sipCall->mCallData.audio_mdp);
        initMDP(&sipCall->mCallData.video_mdp);
        
        //answer audio sdp
        if(sipCall->remoteAudioMDP.size() > 0 && sipCall->mCallData.local_audio_port != 0)
        {
            //m=audio 4444 RTP/AVP 0 \r\n a=rtpmap:0 PCMU/8000\r\n
            const MDP* temp = mappingMDP(engineData.local_audio_mdps,sipCall->remoteAudioMDP);
            if(temp != NULL)
            {
                //sprintf(sdp_string, "c=IN IP4 %s\r\n",sipCall->mCallData.local_audio_ip);
                sprintf(sdp_string, "%sm=audio %d RTP/AVP %d\r\n",sdp_string,sipCall->mCallData.local_audio_port,temp->payload_id);
                //sprintf(sdp_string, "%sc=IN IP4 %s\r\n",sdp_string,sipCall->mCallData.local_audio_ip);
                sprintf(sdp_string, "%sa=rtpmap:%d %s/%d\r\n",sdp_string,temp->payload_id,temp->mime_type,temp->clock_rate);
                
                if(temp->bitrate != 0)
                    sprintf(sdp_string, "%sa=fmtp:%d bitrate=%d\r\n",sdp_string,temp->payload_id,temp->bitrate);
                
                sprintf(sdp_string, "%sa=ptime:20\r\n",sdp_string);
                copyMDP(&sipCall->mCallData.audio_mdp, temp);
                sipCall->mCallData.is_video_call = false;
                
                //a=tool:Quanta QT1.5A_0.0.1
                switch (engineData.product_type) 
                {
                    case call::PRODUCT_TYPE_NA:
                        break;
                    case call::PRODUCT_TYPE_PX:
                        sprintf(sdp_string, "%sa=tool:Quanta ET1_0.0.1\r\n",sdp_string);
                        break;
                    case call::PRODUCT_TYPE_QTA:
                        sprintf(sdp_string, "%sa=tool:Quanta QT1.5A_0.0.1\r\n",sdp_string);
                        break;
                    case call::PRODUCT_TYPE_QTI:
                        sprintf(sdp_string, "%sa=tool:Quanta QT1.5I_0.0.1\r\n",sdp_string);
                        break;
                    case call::PRODUCT_TYPE_QTW:
                        sprintf(sdp_string, "%sa=tool:Quanta QT1.5W_0.0.1\r\n",sdp_string);
                        break;
                    default:
                        break;
                }
                is_match = true;
            }
        }
        if(is_match == false)
            return is_match;
        //answer video sdp
        if(sipCall->remoteVideoMDP.size() > 0 &&  sipCall->mCallData.local_video_port != 0)
        {
            //m=video 6666 RTP/AVP 109\r\n a=rtpmap:109 H264/90000
            const MDP* temp = mappingMDP(engineData.local_video_mdps,sipCall->remoteVideoMDP);
            if(temp != NULL)
            {
                sprintf(sdp_string, "%sm=video %d RTP/AVP %d \r\n",sdp_string,sipCall->mCallData.local_video_port,temp->payload_id);
                //sprintf(sdp_string, "%sc=IN IP4 %s\r\n",sdp_string,sipCall->mCallData.local_video_ip);//Setup connection information
                sprintf(sdp_string, "%sa=rtpmap:%d %s/%d\r\n",sdp_string,temp->payload_id,temp->mime_type,temp->clock_rate);
                
                if(temp->bitrate != 0)
                    sprintf(sdp_string, "%sa=fmtp:%d bitrate=%d\r\n",sdp_string,temp->payload_id,temp->bitrate);
                
                sprintf(sdp_string, "%sa=ptime:20\r\n",sdp_string);
                copyMDP(&sipCall->mCallData.video_mdp, temp);
                sipCall->mCallData.is_video_call = true;
                is_match = true;
            }
        }
        return is_match;
    }
}

#endif
