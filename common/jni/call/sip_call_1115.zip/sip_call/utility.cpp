//
//  Utility.cpp
//  libsofia-sip
//
//  Created by Bill Tocute on 2011/8/19.
//  Copyright 2011年 Quanta. All rights reserved.
//  Steven say to do it 

#include "utility.h"

void empty_mdp_list(std::list<struct call::MDP*> *list)
{
    while(list->size()>0)
    {
        void* data = list->back();
        list->pop_back();
        free(data);
    }
    list->clear();
}

void initMDP(call::MDP *mdp)
{
    mdp->payload_id  = 0;
    mdp->clock_rate  = 0;
    mdp->bitrate     = 0;
    memset(mdp->mime_type , 0, sizeof(mdp->mime_type)/sizeof(char));
}

void copyMDP(call::MDP *tar,const call::MDP *src)
{
    tar->payload_id  = src->payload_id;
    tar->clock_rate  = src->clock_rate;
    tar->bitrate     = src->bitrate;
    strcpy(tar->mime_type, src->mime_type);
}
