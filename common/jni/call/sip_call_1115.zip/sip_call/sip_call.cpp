#include "sip_call.h"
#include <string.h>
namespace sipcall
{
    
    SipCall::SipCall()
    {
        memset((void*)&mCallData,0,sizeof(mCallData));
        mCallData.is_session_start      = false;
        mCallData.is_video_call         = false;
        mCallData.is_reinvite           = false;
        mCallData.is_session_change     = true;
        mCallData.is_caller             = false;
        mCallData.is_send_hold          = false;
        mCallData.call_state            = call::CALL_STATE_NA;
        mCallData.product_type          = call::PRODUCT_TYPE_QTI;
        /* creates a mutex */
        pthread_mutex_init(&mCallData.calldata_lock, NULL);
    }   

    SipCall::~SipCall()
    {
        empty_mdp_list(&remoteAudioMDP);
        empty_mdp_list(&remoteVideoMDP);
        /* destroys the mutex */
        pthread_mutex_destroy(&mCallData.calldata_lock);
    }
    const char* SipCall::getRemoteID()
    {
        return mCallData.remote_id;
    }
    const char*   SipCall::getRemoteDomain()
    {
        return mCallData.remote_domain;
    }
    const char*   SipCall::getRemoteAudioIP()
    {
        return mCallData.remote_audio_ip;
    }
    unsigned int  SipCall::getRemoteAudioPort()
    {
        return mCallData.remote_audio_port;
    }
    const char*   SipCall::getRemoteVideoIP()
    {
        return mCallData.remote_video_ip;
    }
    unsigned int  SipCall::getRemoteVideoPort()
    {
        return mCallData.remote_video_port;
    }
    
    const char*   SipCall::getLocalAudioIP()
    {
        return mCallData.local_audio_ip;
    }
    unsigned int  SipCall::getLocalAudioPort()
    {
        return mCallData.local_audio_port;
    }
    const char*   SipCall::getLocalVideoIP()
    {
        return mCallData.local_video_ip;
    }
    unsigned int  SipCall::getLocalVideoPort()
    {
        return mCallData.local_video_port;
    }

    const call::MDP SipCall::getFinalAudioMDP()
    {
        return mCallData.audio_mdp;
    }
    const call::MDP SipCall::getFinalVideoMDP()
    {
        return mCallData.video_mdp;
    }

    call::ProductType SipCall::getProductType()
    {
        return mCallData.product_type;
    }
    unsigned long SipCall::getStartTime()
    {
        return mCallData.start_time;
    }
    call::CallType SipCall::getCallType()
    {
        return mCallData.call_type;
    }
    call::CallState SipCall::getCallState()
    {
        return mCallData.call_state;
    }
    bool SipCall::isVideoCall()
    {
        return mCallData.is_video_call;
    }
    const char* SipCall::getCallID()
    {
        return mCallData.call_id;
    }
    
    void SipCall::setIDRRequest()
    {
         /*const char *pl = "<media_control><vc_primitive><to_encoder><picture_fast_update/></to_encoder></vc_primitive></media_control>";
         
         nua_info(mCallData.call_handle, 
                  SIPTAG_CONTENT_TYPE_STR("application/media_control+xml"), 
                  SIPTAG_PAYLOAD_STR(pl), 
                  TAG_END());*/
    }
}