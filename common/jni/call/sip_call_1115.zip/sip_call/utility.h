//
//  Utility.h
//  libsofia-sip
//
//  Created by Bill Tocute on 2011/8/19.
//  Copyright 2011年 Quanta. All rights reserved.
//  Steven say to do it 

#ifndef _UTILITY_H
#define _UTILITY_H

#include <list>
#include "mdp.h"

void empty_mdp_list(std::list<struct call::MDP*> *list);
void initMDP(call::MDP *mdp);
void copyMDP(call::MDP *tar,const call::MDP *src);
#endif //_UTILITY_H
